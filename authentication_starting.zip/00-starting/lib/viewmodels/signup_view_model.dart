import 'base_model.dart';
class SignUpViewModel extends BaseModel {
}