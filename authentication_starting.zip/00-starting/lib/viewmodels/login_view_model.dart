import 'base_model.dart';
class LoginViewModel extends BaseModel {
}