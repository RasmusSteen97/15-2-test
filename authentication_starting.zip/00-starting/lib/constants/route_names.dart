const String LoginViewRoute = "LoginView";
const String SignUpViewRoute = "SignUp";
const String HomeViewRoute = "HomeView";
// Generate the views here